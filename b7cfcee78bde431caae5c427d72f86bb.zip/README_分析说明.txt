================================================================================
Ghidra 全面分析结果包 — 靶场文件6.ipa (PitchKit.app / PitchKit)
================================================================================

分析对象
--------------------------------------------------------------------------------
来源文件  : 靶场文件6.ipa (iOS App Zip, 4.0 MB)
主二进制  : Payload/PitchKit.app/PitchKit
          Mach-O 64-bit arm64 executable (PIE, MH_EXECUTE)
          Image base 0x100000000, 约 4.6 MB
App 信息  : PitchKit —— 一个 iOS 音频音高/调音 (pitch detection) App
          使用 Swift 编写，集成 AudioKit / Tonic / SnapKit
          (Bundle 内含 AudioKit_AudioKit.bundle / Tonic_Tonic.bundle / SnapKit_SnapKit.bundle)

分析工具  : Ghidra 12.1.4 (PUBLIC, 2026-09-21 build)
运行环境  : Ubuntu 22.04 x86_64 + OpenJDK 21 (Temurin)
分析模式  : Ghidra Headless (analyzeHeadless) 全量自动分析
           (分析耗时约 288s；含 Objective-C Message Analyzer、
            Objective-C Type Metadata、Swift Type Metadata、Stack、Reference、
            Mach-O Function Starts 等)

关键概况
--------------------------------------------------------------------------------
- 函数数        : 18,276
- 定义符号数    : 71,726
- 导入符号数    : 1,826 (Ghidra) / 1,687 (Mach-O symtab 权威)
- 导出符号(权威): 1 个 (__mh_execute_header，正常可执行文件)
- 内存块(段)    : 51
- 字符串        : 37,889
- 反汇编        : 785,827 行
- 伪代码        : 618,511 行

【重要发现摘要】
--------------------------------------------------------------------------------
1. 这是一个纯 Swift iOS App（调音/练音类），主二进制几乎无 ObjC 自定义类，
   业务逻辑在 Swift 中；Ghidra 已还原出全部 Swift mangled 符号 (_$s...)。
2. 还原出的 App 源码文件路径（内嵌字符串）:
   CusSpace.swift / HomeHeaderView.swift / CustomVStack.swift / WaveScrollView.swift /
   BezierCurveView.swift / BeatCell.swift / VocaliseTips.swift / VocaliseSetupBox.swift /
   KeyCollectionView.swift / DividerView.swift / KeyButton.swift / BlackKey.swift /
   TonoHeaderCell.swift / ToolTipView.swift / CusDotView.swift / HomePianoView.swift /
   HomeTonoView.swift / WhiteKey.swift / MusicKeyboardView.swift / ArchiveCell.swift /
   ScreenControlBox.swift / HomeSideMenuView.swift / SpeedSlider.swift / CustomHStack.swift /
   CustomLabel.swift 等。
3. 网络/加密相关依赖: AVFoundation/AVFAudio、Accelerate、AudioToolbox、CoreMIDI、
   CoreAudioKit、Combine、CryptoKit、libswiftNetwork、libswift_Concurrency、
   StoreKit、SafariServices。Swift 符号中可见 URLRequest / JSONDecoder 调用。
4. 内嵌 URL:
   - https://beian.miit.gov.cn/#/Integrated/index  (ICP 备案)
   - https://www.leleyes.com
5. UserDefaults / 设置键 (App 偏好项):
   _isShowKeepLineKeyboard / _isShow3LinkNoteKeyboard / _startKeyNoteName /
   _isShowPianoNumberKeyName / isShowPianoNumberKeyNameKey / _keyboardSizeLevel /
   keyboardSizeLevelKey / lineFilterLevelKey。
6. 媒体资源: App 内打包 p01.mp3 ~ p13.mp3 (音阶/示范音频样本)。
7. 注意: Swift 函数经 SIL/泛型特化后多为 thunk / closure，Ghidra 对薄 thunk
   的伪代码会显示为间接调用 (*(code*)...)，属正常现象；有实体的业务函数
   （HomePianoView / WaveScrollView / KeyCollectionView 等视图与音频处理函数）
   已给出完整反编译 C。

================================================================================
包内文件清单 (每个类别一个独立 txt)
================================================================================

00_overview.txt            分析总览 (Ghidra 版本、语言、导入导出/函数/段数量)
--------------------------------------------------------------------------------
一、符号与命名空间 (Symbol & Namespace)
01_symbols.txt             完整符号树 (71,726 定义符号, 地址排序)
02_imports.txt             导入 (Ghidra 外部符号 + 引用位置)
03_exports.txt             导出 (全局/入口符号)
04_functions.txt            函数列表 (地址/大小/符号名, 18,276 个)
05_classes_namespaces.txt   类与命名空间 (按父命名空间统计)
--------------------------------------------------------------------------------
二、Mach-O 元数据与内存布局
06_macho_metadata.txt       段与节 (Ghidra 51 个内存块) + 原始 Mach-O 加载命令
                            (LC_SEGMENT_64 全部节、LC_SYMTAB、LC_DYSYMTAB、
                             LC_LOAD_DYLIB 依赖列表、符号表权威导入/导出)
07_linking_fixups.txt       链接与修复 (导入符号及其引用站点)
--------------------------------------------------------------------------------
三、代码与数据引用 (XREF)
08_code_xrefs.txt           代码引用 (函数被谁调用)
09_data_xrefs.txt           数据引用 (数据/字符串/常量被谁引用)
--------------------------------------------------------------------------------
四、字符串与常量
10_strings.txt              全部字符串 (37,889 个)
11_objc_methods.txt         Objective-C 方法名/selector 字符串
12_ui_text_errors.txt       UI 文本与错误信息 (error/fail/invalid/denied 等)
13_hardcoded_keys_paths.txt 硬编码密钥/路径/URL (含网络 URL、设置键、keychain 相关)
--------------------------------------------------------------------------------
五、控制流图与函数细节
15_disassembly.txt          反汇编列表 (全部函数 arm64, 含机器码字节)
16_pseudocode.txt           反编译伪代码 (全部函数 C 伪码)
17_control_flow.txt         函数图细节 (签名/返回类型/参数/局部变量/调用约定/属性)
--------------------------------------------------------------------------------
六、语言特定元数据
18_language_metadata.txt    Objective-C (类/元类/分类/协议) 与
                            Swift (全部 _$s mangled 符号、Swift runtime 引用) 元数据

================================================================================
使用说明
--------------------------------------------------------------------------------
- 文件为 UTF-8 纯文本。大文件 (15/16/17) 建议用 less/grep/awk 或支持大文件的编辑器。
- 地址均为虚拟地址，image base = 0x100000000。
- "FUN_xxxxxxxx" 为 Ghidra 未识别的内部函数；有名称的为符号已识别
  (Swift mangled / ObjC selector / 导入函数)。
- Swift mangled 符号名以 _$s 开头，可用 `swift demangle` 还原为可读签名；
  反编译输出中以 __$s... 命名的函数即为对应 Swift 函数。

================================================================================
数据口径
--------------------------------------------------------------------------------
- "导出符号(权威)" 直接解析 Mach-O LC_SYMTAB 外部定义符号，共 1 个
  (__mh_execute_header)，见 06_macho_metadata.txt。
- 导入两份口径：Ghidra 外部符号 1,826 (02/07)，Mach-O 符号表未定义符号 1,687 (06)。
- 加载命令原始解析见 06_macho_metadata.txt 后半段。
